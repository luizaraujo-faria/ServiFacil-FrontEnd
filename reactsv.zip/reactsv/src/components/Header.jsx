import styles from '../styles/Header.module.css';

export default function Header({ onSearch }) {
  return (
    <header className={styles.header}>
      <div className={styles.logo}>ServiFácil</div>
      <div className={styles.searchBox}>
        <input
          type="text"
          placeholder="Buscar serviços..."
          onChange={(e) => onSearch(e.target.value)}
        />
      </div>
    </header>
  );
}
