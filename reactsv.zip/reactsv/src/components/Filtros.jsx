import styles from '../styles/Filtros.module.css';

export default function Filtros({ filtros, setFiltros }) {
  const handleChange = (e) => {
    setFiltros({ ...filtros, [e.target.name]: e.target.value });
  };

  return (
    <section className={styles.filtros}>
      <select name="servico" onChange={handleChange}>
        <option>Todos os serviços</option>
        <option>Eletricista</option>
        <option>Encanador</option>
      </select>

      <select name="localizacao" onChange={handleChange}>
        <option>Toda a cidade</option>
        <option>Zona Norte</option>
        <option>Zona Sul</option>
      </select>

      <select name="preco" onChange={handleChange}>
        <option>Qualquer preço</option>
        <option>Até R$100</option>
        <option>R$100 - R$200</option>
      </select>

      <select name="avaliacao" onChange={handleChange}>
        <option>Todas as avaliações</option>
        <option>5 estrelas</option>
        <option>4+ estrelas</option>
      </select>
    </section>
  );
}
