import styles from '../styles/Card.module.css';
import { useState, useEffect } from 'react';

const FAV_KEY = 'servifacil_favs_v1';

export default function Card({ profissional }) {
  const [isFavorito, setIsFavorito] = useState(false);

  useEffect(() => {
    const favs = JSON.parse(localStorage.getItem(FAV_KEY) || '[]');
    setIsFavorito(favs.includes(profissional.id));
  }, [profissional.id]);

  const toggleFavorito = () => {
    const favs = JSON.parse(localStorage.getItem(FAV_KEY) || '[]');
    let atualizados;

    if (favs.includes(profissional.id)) {
      atualizados = favs.filter(id => id !== profissional.id);
    } else {
      atualizados = [...favs, profissional.id];
    }

    localStorage.setItem(FAV_KEY, JSON.stringify(atualizados));
    setIsFavorito(!isFavorito);
  };

  return (
    <div className={styles.card}>
      <img src={profissional.img} alt={profissional.nome} />
      <h3>{profissional.nome}</h3>
      <p>{profissional.profissao}</p>
      <p className={styles.preco}>{profissional.preco}</p>
      <button>Agendar</button>
      <button
        className={`${styles.favBtn} ${isFavorito ? styles.favorited : ''}`}
        onClick={toggleFavorito}
        aria-label="Favoritar"
      >
        {isFavorito ? '♥' : '♡'}
      </button>
    </div>
  );
}
