import styles from '../styles/Servicos.module.css';
import Card from './Card';

export default function Servicos({ dados, filtros, busca, paginaAtual, setPaginaAtual, porPagina }) {
  const aplicaFiltros = () => {
    return dados.filter(item => {
      const nomeProfissao = (item.nome + ' ' + item.profissao).toLowerCase();

      const filtroServico = filtros.servico && !filtros.servico.toLowerCase().includes('todos')
        ? item.profissao.toLowerCase() === filtros.servico.toLowerCase()
        : true;

      const filtroLocal = filtros.localizacao && !filtros.localizacao.toLowerCase().includes('toda')
        ? item.local?.toLowerCase() === filtros.localizacao.toLowerCase()
        : true;

      const filtroPreco = (() => {
        if (!filtros.preco || filtros.preco.includes('Qualquer')) return true;
        const valor = parseFloat(item.preco.replace(/[^\d,]/g, '').replace(',', '.'));
        if (filtros.preco.includes('Até')) {
          const limite = parseFloat(filtros.preco.replace(/[^\d,]/g, '').replace(',', '.'));
          return valor <= limite;
        } else if (filtros.preco.includes('-')) {
          const [min, max] = filtros.preco.match(/\d+/g).map(Number);
          return valor >= min && valor <= max;
        }
        return true;
      })();

      const filtroAvaliacao = (() => {
        if (!filtros.avaliacao || filtros.avaliacao.includes('Todas')) return true;
        const nota = parseFloat(item.avaliacao ?? 0);
        if (filtros.avaliacao.includes('5')) return nota === 5;
        if (filtros.avaliacao.includes('4')) return nota >= 4;
        return true;
      })();

      const filtroBusca = nomeProfissao.includes(busca.toLowerCase());

      return filtroServico && filtroLocal && filtroPreco && filtroAvaliacao && filtroBusca;
    });
  };

  const resultados = aplicaFiltros();
  const inicio = (paginaAtual - 1) * porPagina;
  const paginados = resultados.slice(inicio, inicio + porPagina);

  return (
    <main className={styles.servicos}>
      {paginados.length === 0 ? (
        <div className={styles.semResultados}>Nenhum serviço encontrado.</div>
      ) : (
        paginados.map(item => <Card key={item.id} profissional={item} />)
      )}
    </main>
  );
}
