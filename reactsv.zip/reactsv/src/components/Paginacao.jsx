import styles from '../styles/Paginacao.module.css';

export default function Paginacao({ total, porPagina, paginaAtual, setPaginaAtual }) {
  const totalPaginas = Math.ceil(total / porPagina);

  const paginas = [];
  for (let i = 1; i <= totalPaginas; i++) {
    paginas.push(i);
  }

  return (
    <div className={styles.paginacao}>
      <button onClick={() => setPaginaAtual(p => Math.max(p - 1, 1))} disabled={paginaAtual === 1}>
        &lt;
      </button>
      {paginas.map(num => (
        <button
          key={num}
          className={paginaAtual === num ? styles.ativo : ''}
          onClick={() => setPaginaAtual(num)}
        >
          {num}
        </button>
      ))}
      <button onClick={() => setPaginaAtual(p => Math.min(p + 1, totalPaginas))} disabled={paginaAtual === totalPaginas}>
        &gt;
      </button>
    </div>
  );
}
