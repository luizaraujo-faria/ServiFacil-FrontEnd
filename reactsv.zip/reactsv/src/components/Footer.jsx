import styles from '../styles/Footer.module.css';

export default function Footer() {
  return (
    <footer className={styles.footer}>
      <div className={styles.col}>
        <h4>ServiFácil</h4>
        <p>Conectando você aos melhores profissionais da sua região.</p>
      </div>
      <div className={styles.col}>
        <h4>Serviços</h4>
        <ul>
          <li>Eletricista</li>
          <li>Encanador</li>
          <li>Diarista</li>
          <li>Pintor</li>
        </ul>
      </div>
      <div className={styles.col}>
        <h4>Contato</h4>
        <p>(11) 9999-9999</p>
        <p>contato@servifacil.com</p>
        <p>São Paulo, SP</p>
      </div>
    </footer>
  );
}
