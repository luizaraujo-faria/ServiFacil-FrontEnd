import { useEffect, useState } from 'react';
import profissionais from './assets/data'; // dados reais
import Header from './components/Header';
import Filtros from './components/Filtros';
import Servicos from './components/Servicos';
import Paginacao from './components/Paginacao';
import Footer from './components/Footer';

function App() {
  const [dados, setDados] = useState([]);
  const [filtros, setFiltros] = useState({
    servico: '',
    localizacao: '',
    preco: '',
    avaliacao: '',
  });
  const [busca, setBusca] = useState('');
  const [paginaAtual, setPaginaAtual] = useState(1);
  const porPagina = 8;

  // Carrega os dados do arquivo
  useEffect(() => {
    setDados(profissionais);
  }, []);

  // Aplica filtros
  const dadosFiltrados = dados.filter((prof) => {
    const matchServico =
      !filtros.servico || prof.servico.toLowerCase().includes(filtros.servico.toLowerCase());
    const matchLocalizacao =
      !filtros.localizacao || prof.localizacao?.toLowerCase().includes(filtros.localizacao.toLowerCase());
    const matchPreco =
      !filtros.preco || prof.precoValue <= Number(filtros.preco);
    const matchAvaliacao =
      !filtros.avaliacao || prof.avaliacao >= Number(filtros.avaliacao);
    const matchBusca =
      !busca || prof.nome.toLowerCase().includes(busca.toLowerCase()) || prof.servico.toLowerCase().includes(busca.toLowerCase());

    return matchServico && matchLocalizacao && matchPreco && matchAvaliacao && matchBusca;
  });

  // Paginação
  const inicio = (paginaAtual - 1) * porPagina;
  const fim = inicio + porPagina;
  const dadosPaginados = dadosFiltrados.slice(inicio, fim);

  return (
    <>
      <Header busca={busca} setBusca={setBusca} />
      <Filtros filtros={filtros} setFiltros={setFiltros} />
      <Servicos
        dados={dadosPaginados}
      />
      <Paginacao
        total={dadosFiltrados.length}
        porPagina={porPagina}
        paginaAtual={paginaAtual}
        setPaginaAtual={setPaginaAtual}
      />
      <Footer />
    </>
  );
}

export default App;
