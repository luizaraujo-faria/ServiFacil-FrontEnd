const profissionais = [
  {
    nome: "João Silva",
    servico: "Eletricista",
    preco: "R$ 80/hora",
    imagem: "https://images.pexels.com/photos/4116233/pexels-photo-4116233.jpeg"
  },
  {
    nome: "Maria Santos",
    servico: "Encanadora",
    preco: "R$ 120/visita",
    imagem: "https://images.pexels.com/photos/7568417/pexels-photo-7568417.jpeg"
  },
  {
    nome: "Ana Costa",
    servico: "Diarista",
    preco: "R$ 150/dia",
    imagem: "https://images.pexels.com/photos/2744849/pexels-photo-2744849.jpeg"
  },
  {
    nome: "Carlos Oliveira",
    servico: "Pintor",
    preco: "R$ 200/dia",
    imagem: "https://images.pexels.com/photos/6615283/pexels-photo-6615283.jpeg"
  },
  {
    nome: "Pedro Lima",
    servico: "Técnico em Ar Condicionado",
    preco: "R$ 90/hora",
    imagem: "https://images.pexels.com/photos/6196231/pexels-photo-6196231.jpeg"
  },
  {
    nome: "Lucia Fernandes",
    servico: "Jardineira",
    preco: "R$ 180/dia",
    imagem: "https://images.pexels.com/photos/6773235/pexels-photo-6773235.jpeg"
  },
  {
    nome: "Roberto Souza",
    servico: "Marceneiro",
    preco: "R$ 250/projeto",
    imagem: "https://images.pexels.com/photos/3846583/pexels-photo-3846583.jpeg"
  },
  {
    nome: "Fernanda Rocha",
    servico: "Babá",
    preco: "R$ 100/dia",
    imagem: "https://images.pexels.com/photos/32432122/pexels-photo-32432122.jpeg"
  },
  {
    nome: "Juliana Alves",
    servico: "Costureira",
    preco: "R$ 70/peça",
    imagem: "https://images.pexels.com/photos/31986416/pexels-photo-31986416.jpeg"
  },
  {
    nome: "Marcelo Nunes",
    servico: "Pedreiro",
    preco: "R$ 180/dia",
    imagem: "https://images.pexels.com/photos/6713705/pexels-photo-6713705.jpeg"
  },
  {
    nome: "Patrícia Gomes",
    servico: "Cuidadora de Idosos",
    preco: "R$ 150/dia",
    imagem: "https://images.pexels.com/photos/27865295/pexels-photo-27865295.jpeg"
  },
  {
    nome: "Daniel Freitas",
    servico: "Professor Particular",
    preco: "R$ 60/hora",
    imagem: "https://images.pexels.com/photos/8547341/pexels-photo-8547341.jpeg"
  },
  {
    nome: "Renata Lima",
    servico: "Personal Trainer",
    preco: "R$ 120/hora",
    imagem: "https://images.pexels.com/photos/414029/pexels-photo-414029.jpeg"
  },
  {
    nome: "Gabriel Costa",
    servico: "Fotógrafo",
    preco: "R$ 300/evento",
    imagem: "https://images.pexels.com/photos/4088245/pexels-photo-4088245.jpeg"
  },
  {
    nome: "Camila Ferreira",
    servico: "Designer Gráfico",
    preco: "R$ 400/projeto",
    imagem: "https://images.pexels.com/photos/3184657/pexels-photo-3184657.jpeg"
  },
  {
    nome: "Rafael Moreira",
    servico: "Motorista Particular",
    preco: "R$ 150/dia",
    imagem: "https://images.pexels.com/photos/4391488/pexels-photo-4391488.jpeg"
  },
  {
    nome: "Beatriz Mendes",
    servico: "Maquiadora",
    preco: "R$ 180/evento",
    imagem: "https://images.pexels.com/photos/29616387/pexels-photo-29616387.jpeg"
  },
  {
    nome: "Rodrigo Martins",
    servico: "DJ",
    preco: "R$ 500/evento",
    imagem: "https://images.pexels.com/photos/1649691/pexels-photo-1649691.jpeg"
  },
  {
    nome: "Larissa Pires",
    servico: "Nutricionista",
    preco: "R$ 200/consulta",
    imagem: "https://images.pexels.com/photos/7446600/pexels-photo-7446600.jpeg"
  },
  {
    nome: "Thiago Barbosa",
    servico: "Mecânico",
    preco: "R$ 100/hora",
    imagem: "https://images.pexels.com/photos/4116233/pexels-photo-4116233.jpeg"
  },
  {
    nome: "Isabela Cunha",
    servico: "Arquiteta",
    preco: "R$ 500/projeto",
    imagem: "https://images.pexels.com/photos/6615234/pexels-photo-6615234.jpeg"
  },
  {
    nome: "Felipe Araújo",
    servico: "Programador Freelancer",
    preco: "R$ 80/hora",
    imagem: "https://images.pexels.com/photos/8866725/pexels-photo-8866725.jpeg"
  },
  {
    nome: "Carolina Lopes",
    servico: "Advogada",
    preco: "R$ 350/consulta",
    imagem: "https://images.pexels.com/photos/8134074/pexels-photo-8134074.jpeg"
  },
  {
    nome: "André Silva",
    servico: "Veterinário",
    preco: "R$ 200/consulta",
    imagem: "https://images.pexels.com/photos/1350591/pexels-photo-1350591.jpeg"
  }
];

export default profissionais;
