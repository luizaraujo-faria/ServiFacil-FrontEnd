
document.addEventListener('DOMContentLoaded', () => {
  const searchInput = document.querySelector('.search-box input');
  const selects = Array.from(document.querySelectorAll('.filtros select'));
  const [selService, selLocation, selPrice, selRating] = selects;
  const cardsContainer = document.querySelector('.servicos');
  let cards = Array.from(cardsContainer.querySelectorAll('.card'));
  const pagContainer = document.querySelector('.paginacao');
  const perPage = 8;
  let currentPage = 1;
  const favsKey = 'servifacil_favs_v1';
  const savedFavs = JSON.parse(localStorage.getItem(favsKey) || '[]');

  // ensure each card has a stable id and meta
  cards.forEach((card, idx) => {
    if (!card.dataset.id) {
      const name = (card.querySelector('h3')?.innerText || 'card').trim().toLowerCase().replace(/\s+/g,'-');
      card.dataset.id = `${name}-${idx}`;
    }

    const name = (card.querySelector('h3')?.innerText || '').trim();
    // profession: first <p> that is not .preco
    const professionEl = Array.from(card.querySelectorAll('p')).find(p => !p.classList.contains('preco'));
    const profession = (professionEl?.innerText || '').trim();

    // price: prefer data-price, else try to parse from .preco text
    let price = null;
    if (card.dataset.price) price = parseFloat(String(card.dataset.price).replace(',', '.'));
    else {
      const priceEl = card.querySelector('.preco');
      if (priceEl) {
        const t = priceEl.innerText.replace(/\./g, '').replace(',', '.');
        const m = t.match(/\d+(\.\d+)?/);
        price = m ? parseFloat(m[0]) : null;
      }
    }

    const rating = card.dataset.rating ? parseFloat(card.dataset.rating) : (card.dataset.rating ? parseFloat(card.dataset.rating) : 0);
    const service = card.dataset.service || profession || '';

    card._meta = { name, profession, price, rating, service };
    // make sure card allows absolutely-positioned favorites
    card.style.position = card.style.position || getComputedStyle(card).position === 'static' ? 'relative' : '';
  });

  // create favorite button if missing and wire persistence
  cards.forEach(card => {
    let btn = card.querySelector('.fav-btn');
    if (!btn) {
      btn = document.createElement('button');
      btn.className = 'fav-btn';
      btn.setAttribute('aria-label', 'Favoritar');
      btn.innerHTML = '♡';
      card.appendChild(btn);
    }
    const isFav = savedFavs.includes(card.dataset.id);
    if (isFav) { btn.classList.add('favorited'); btn.innerHTML = '♥'; }
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      let favs = JSON.parse(localStorage.getItem(favsKey) || '[]');
      if (favs.includes(card.dataset.id)) {
        favs = favs.filter(id => id !== card.dataset.id);
        btn.classList.remove('favorited');
        btn.innerHTML = '♡';
      } else {
        favs.push(card.dataset.id);
        btn.classList.add('favorited');
        btn.innerHTML = '♥';
      }
      localStorage.setItem(favsKey, JSON.stringify(favs));
    });
  });

  // Apply filters + search -> compute visible cards -> show page slice
  function applyFilters() {
    const q = (searchInput?.value || '').toLowerCase().trim();
    const serviceVal = selService?.value || '';
    const locVal = selLocation?.value || '';
    const priceVal = selPrice?.value || '';
    const ratingVal = selRating?.value || '';

    const visible = [];
    cards.forEach(card => {
      const m = card._meta;
      let ok = true;

      // pesquisa por nome ou profissão
      if (q && !(m.name.toLowerCase().includes(q) || m.profession.toLowerCase().includes(q))) ok = false;

      // filtro serviço
      if (serviceVal && !/^todos/i.test(serviceVal) && m.service && serviceVal.toLowerCase() !== m.service.toLowerCase()) ok = false;

      // filtro local (se usar data-location nos cards)
      if (locVal && !/^toda a cidade/i.test(locVal) && card.dataset.location) {
        if (locVal.toLowerCase() !== card.dataset.location.toLowerCase()) ok = false;
      }

      // filtro preço (interpreta "Até R$100" e "R$100 - R$200")
      if (priceVal && !/^qualquer/i.test(priceVal) && m.price != null) {
        const raw = priceVal.replace(/\s/g,'');
        if (/Até/i.test(priceVal)) {
          const num = parseFloat(priceVal.replace(/[^\d,\.]/g,'').replace(',', '.'));
          if (!(m.price <= num)) ok = false;
        } else if (/-/.test(raw)) {
          const nums = raw.match(/\d+/g);
          if (nums && nums.length >= 2) {
            const low = parseFloat(nums[0]);
            const high = parseFloat(nums[1]);
            if (!(m.price >= low && m.price <= high)) ok = false;
          }
        }
      }

      // filtro avaliação (simples)
      if (ratingVal && !/todas/i.test(ratingVal)) {
        if (/5/.test(ratingVal) && (m.rating || 0) < 5) ok = false;
        else if (/4/.test(ratingVal) && (m.rating || 0) < 4) ok = false;
      }

      if (ok) visible.push(card);
    });

    // reset to first page when filters change
  
    renderPage(visible);
  }

  // render the requested page of visibleCards
  function renderPage(visibleCards) {
    // hide all first
    cards.forEach(c => c.style.display = 'none');

    const total = visibleCards.length;
    const totalPages = Math.max(1, Math.ceil(total / perPage));
    if (currentPage > totalPages) currentPage = totalPages;

    const start = (currentPage - 1) * perPage;
    const pageItems = visibleCards.slice(start, start + perPage);
    pageItems.forEach(c => c.style.display = '');

    renderPaginationUI(totalPages, total);
    // if no results, show message
    handleEmptyState(total === 0);
  }

  function renderPaginationUI(totalPages, totalItems) {
    if (!pagContainer) return;
    pagContainer.innerHTML = '';
    // previous
    const prev = document.createElement('button');
    prev.textContent = '<';
    prev.disabled = (currentPage === 1);
    prev.addEventListener('click', () => { if (currentPage > 1) { currentPage--; applyFilters(); } });
    pagContainer.appendChild(prev);

    // pages (limit when many pages)
    const maxButtons = 7;
    let startPage = 1, endPage = totalPages;
    if (totalPages > maxButtons) {
      const half = Math.floor(maxButtons / 2);
      startPage = Math.max(1, currentPage - half);
      endPage = Math.min(totalPages, startPage + maxButtons - 1);
      if (endPage - startPage < maxButtons - 1) startPage = Math.max(1, endPage - maxButtons + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      const btn = document.createElement('button');
      btn.textContent = String(i);
      if (i === currentPage) btn.classList.add('ativo');
      btn.addEventListener('click', () => { currentPage = i; applyFilters(); });
      pagContainer.appendChild(btn);
    }

    // next
    const next = document.createElement('button');
    next.textContent = '>';
    next.disabled = (currentPage === totalPages);
    next.addEventListener('click', () => { if (currentPage < totalPages) { currentPage++; applyFilters(); } });
    pagContainer.appendChild(next);

    // summary (opcional)
    const info = document.createElement('span');
    info.style.marginLeft = '8px';
    info.textContent = `${totalItems} encontrado(s)`;
    pagContainer.appendChild(info);
  }

  function handleEmptyState(isEmpty) {
    let emptyEl = document.querySelector('.no-results');
    if (!emptyEl) {
      emptyEl = document.createElement('div');
      emptyEl.className = 'no-results';
      emptyEl.style.padding = '20px';
      emptyEl.style.textAlign = 'center';
      emptyEl.style.gridColumn = '1/-1';
      emptyEl.innerText = 'Nenhum serviço encontrado.';
      cardsContainer.appendChild(emptyEl);
    }
    emptyEl.style.display = isEmpty ? '' : 'none';
  }

  // wire inputs
  if (searchInput) searchInput.addEventListener('input', debounce(applyFilters, 200));
  [selService, selLocation, selPrice, selRating].forEach(s => s && s.addEventListener('change', applyFilters));

  // initial render
  applyFilters();

  // small debounce helper
  function debounce(fn, wait) {
    let t;
    return function(...args) {
      clearTimeout(t);
      t = setTimeout(() => fn.apply(this, args), wait);
    };
  }
});
